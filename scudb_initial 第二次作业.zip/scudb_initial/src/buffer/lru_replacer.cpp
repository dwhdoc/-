/**
 * LRU implementation
 */
#include "buffer/lru_replacer.h"
#include "page/page.h"

namespace scudb {

template <typename T> LRUReplacer<T>::LRUReplacer() {
  head = make_shared<Node>();
  tail = make_shared<Node>();
  head->next = tail;
  tail->prev = head;
}

template <typename T> LRUReplacer<T>::~LRUReplacer() {}

/*
 * Insert value into LRU
 */
/*
template <typename T> void LRUReplacer<T>::Insert(const T &value) {
  lock_guard<mutex> lck(latch);
  shared_ptr<Node> cur;
  if (map.find(value) != map.end()) {
    cur = map[value];
    shared_ptr<Node> prev = cur->prev;
    shared_ptr<Node> succ = cur->next;
    prev->next = succ;
    succ->prev = prev;
  } else {
    cur = make_shared<Node>(value);
  }
  shared_ptr<Node> fir = head->next;
  cur->next = fir;
  fir->prev = cur;
  cur->prev = head;
  head->next = cur;
  map[value] = cur;
  return;
}*/

template <typename T> void LRUReplacer<T>::Insert(const T &value) {
  lock_guard<mutex> lck(latch);
  shared_ptr<Node> curr;
  if (map.find(value) != map.end()) {
    curr = map[value];
    shared_ptr<Node> prev = curr->prev;
    shared_ptr<Node> succ = curr->next;
    prev->next = succ;
    succ->prev = prev;
  } else {
    cur = make_shared<Node>(value);
  }
  shared_ptr<Node> fir = head->next;
  curr->next = fir;
  fir->prev = curr;
  curr->prev = head;
  head->next = curr;
  map[value] = curr;
  return;
}//mine


/* If LRU is non-empty, pop the head member from LRU to argument "value", and
 * return true. If LRU is empty, return false
 */
/*template <typename T> bool LRUReplacer<T>::Victim(T& value) {
  lock_guard<mutex> lck(latch);
  if (map.empty()) {
    return false;
  }
  shared_ptr<Node> last = tail->prev;
  tail->prev = last->prev;
  last->prev->next = tail;
  value = last->val;
  map.erase(last->val);
  return true;
}
*/
template <typename T> bool LRUReplacer<T>::Victim(T& value) {
    lock_guard<mutex> lck(latch);
    if (map.empty() == true) {
        return false;
    }
    shared_ptr<Node> temlast = tail->prev;
    tail->prev = temlast->prev;
    temlast->prev->next = tail;
    value = temlast->val;
    map.erase(temlast->val);
    return true;
}
/*
 * Remove value from LRU. If removal is successful, return true, otherwise
 * return false
 */
template <typename T> bool LRUReplacer<T>::Erase(const T &value) {
  lock_guard<mutex> lck(latch);
  if (map.find(value) != map.end()) {
    shared_ptr<Node> curr = map[value];
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
  }
  return map.erase(value);
}

template <typename T> size_t LRUReplacer<T>::Size() {
  lock_guard<mutex> lck(latch);
  return map.size();
}

template class LRUReplacer<Page *>;
// test only
template class LRUReplacer<int>;

} // namespace scudb
